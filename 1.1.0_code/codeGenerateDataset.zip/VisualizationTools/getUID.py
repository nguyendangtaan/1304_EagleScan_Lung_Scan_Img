from utils import *


# path = 'Data/02-06-2020/DICOM/Lung_Dx-G0011'
# path = '/home/wangshuo/Desktop/test_data/Lung-PET-CT-Dx/G0011'
# path = 'Data/02-06-2020/DICOM/Lung_Dx-G0011/04-29-2009-LUNGC-51228/2.000000-A phase 5mm Stnd SS50-53792/2-017.dcm'


def getUID_path(path):
    uid_dict = {}

    for root, _, files in os.walk(path):
        for filename in files:
            # Bỏ qua file không phải DICOM
            if not filename.lower().endswith(".dcm"):
                continue

            dicom_path = os.path.join(root, filename)

            try:
                info = loadFileInformation(dicom_path)
                uid = info['dicom_num']
                uid_dict[uid] = (dicom_path, filename)
            except Exception as e:
                print(f"[WARN] Skip file {dicom_path}, reason: {e}")
                continue

    return uid_dict


def getUID_file(path):
    try:
        info = loadFileInformation(path)
        return info['dicom_num']
    except Exception as e:
        print(f"[ERROR] Cannot read file {path}, reason: {e}")
        return None

# dict = getUID_file(path)
# print(dict)